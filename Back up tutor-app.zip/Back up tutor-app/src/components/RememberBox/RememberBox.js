// This is the check box to indicate for Remember actions 
// Does not work for now, need to fix 
import React, { useState } from "react";
import { Text, StyleSheet, View } from "react-native";
import CheckBox from '@react-native-community/checkbox';

// function RememberBox() {
//       <View style={styles.container}>
//       <View style={styles.checkboxContainer}>
//       const [toggleCheckBox, setToggleCheckBox] = useState(false)

//         <CheckBox
//           disabled={false}
//           value={toggleCheckBox}
//           onValueChange={(newValue) => setToggleCheckBox(newValue)}
//         />

//         <Text style={styles.label}>Do you like React Native?</Text>
//       </View>
//       <Text>Is CheckBox selected: {isSelected ? "👍" : "👎"}</Text>
//     </View>
// } 


function RememberBox() {
    // <View style={styles.container}>
    //   <View style={styles.checkboxContainer}>
    //     <CheckBox
    //       value={isSelected}
    //       onValueChange={setSelection}
    //       style={styles.checkbox}
    //     />
    //     <Text style={styles.label}>Do you like React Native?</Text>
    //   </View>
    //   <Text>Is CheckBox selected: {isSelected ? "👍" : "👎"}</Text>
    // </View>
} 

export default RememberBox;
// This is the sub header for our sign in page 
import React from 'react';
function SubHeader() {
    return(
        <div>
            <h1> Sign In </h1>
        </div>
    )
}
export default SubHeader;
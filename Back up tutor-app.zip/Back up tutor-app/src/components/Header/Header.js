// This is the header for our application to show the name of the our application
import React from 'react';
function Header() {
    return(
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div className="row col-1.5 d-flex justify-content-center text-blue">
            <span className="h3">Bruin Tutors</span>
            </div>
        </nav>
    )
}
export default Header;
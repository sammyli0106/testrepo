
import React, {useState, Component} from 'react';
import SignIn from './components/SignIn/SignIn';
import Header from './components/Header/Header';
import SubHeader from './components/SubHeader/SubHeader';
import FootHeader from './components/FootHeader/FootHeader';

// import RememberBox from './components/RememberBox/RememberBox';

// This relate to the processing of the input of the sign in page, not sure about it 
// import {
//   BrowserRouter as Router,
//   Switch,
//   Route
// } from "react-router-dom";

import Popup from './components/Popup/Popup';

class App extends Component {  

    constructor(props){  
    super(props);  
    this.state = { showPopup: false,
                   showPopup2: false };  
    }  

    togglePopup() {  
    this.setState({  
        showPopup: !this.state.showPopup
    });  
    }  

    togglePopup2() {
      this.setState({  
        showPopup2: !this.state.showPopup2
    });  
    }  

  render() {  
  return (  

      <div>  

        <Header/>
        <div className="container d-flex align-items-center flex-column">
        <SubHeader></SubHeader>
        <SignIn />

        <button onClick={this.togglePopup.bind(this)}> Privacy Policy</button>  
        <button onClick={this.togglePopup2.bind(this)}> Terms of Use </button>
        {this.state.showPopup ?  
          <Popup  
                    text='We reserve the right to make changes to this Privacy Policy at any time and for any reason.'  
                    closePopup={this.togglePopup.bind(this)}  
          />  
          : null  
        }  
        {this.state.showPopup2 ?  
          <Popup  
                    text='Content of the Terms of Use'  
                    closePopup={this.togglePopup2.bind(this)}  
          />  
          : null  
        }  
        
        <FootHeader/>
        </div>
      </div>  

  );  
}  
}  

export default App;


// This is a functional format of the App 
// function App() {
// return (
//     // <Router>
//     <div className="App">
      // <Header/>
      //   <div className="container d-flex align-items-center flex-column">
      //     <SubHeader></SubHeader>
      //     <SignIn />
//           {/* <RememberBox/> */}
          
//                 <button>
//                     Privacy Policy
//                 </button>

//                 <button>
//                     Term of Use
//                 </button>

//           <FootHeader/>
//        </div>
//    </div>
//   // </Router>
//   )  
// }

// export default App;
